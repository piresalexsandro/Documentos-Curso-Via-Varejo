package br.com.vvcurso.entidade;

public class PedidoCaudaLonga extends Pedido {


	public void emitirNF() {

	}

	@Override
	public void cancelar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void abrir() {
		// TODO Auto-generated method stub

	}
}
