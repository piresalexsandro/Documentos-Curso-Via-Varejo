package br.com.vvcurso.entidade;

public interface IPedido {
   void cancelar();
   void pagar();
   void abrir();
}
